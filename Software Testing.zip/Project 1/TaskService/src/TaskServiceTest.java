import static org.junit.Assert.*;
import org.junit.Test;


public class TaskServiceTest {
	
	//testing add functionality pass
	@Test
	public void testAddPass() {
		TaskService t = new TaskService();
		Task testAddPass1 = new Task("1", "Module 1", "Submit Module 1");
		Task testAddPass2 = new Task("2", "Module 2", "Submit Module 2");
		assertEquals(true, t.add(testAddPass1));
		assertEquals(true, t.add(testAddPass2));
	
	}

	//testing add functionality for fail
	@Test
	public void testMethodAddFail() {
		TaskService t = new TaskService();
		Task testAddFail1 = new Task("1", "Module 1", "Submit Module 1");

		//test id already added
		assertEquals(true, t.add(testAddFail1));
		assertEquals(false, t.add(testAddFail1));

		}

	
	//test delete functionality pass
	@Test
	public void testMethodDeletePass() {
		TaskService t = new TaskService();
		Task testDeletePass1 = new Task("1", "Module 1", "Submit Module 1");
		Task testDeletePass2 = new Task("2", "Module 2", "Submit Module 2");
		assertEquals(true, t.add(testDeletePass1));
		assertEquals(true, t.add(testDeletePass2));

		assertEquals(true, t.remove("1"));
		assertEquals(true, t.remove("2"));
}

	//test delete method fail
	@Test
	public void testMethodDeleteFail() {
		TaskService t = new TaskService();
		Task testDeleteFail1 = new Task("1", "Module 1", "Submit Module 1");
		Task testDeleteFail2 = new Task("2", "Module 2", "Submit Module 2");
		assertEquals(true, t.add(testDeleteFail1));
		assertEquals(true, t.add(testDeleteFail2));
		
		//test removing contact that does not exist
		assertEquals(false, t.remove("3"));
		//test removing regular contact
		assertEquals(true, t.remove("2"));
}

	// test update pass
	@Test
	public void testUpdatePass() {
		TaskService t = new TaskService();
		Task testUpdatePass1 = new Task("1", "Module 1", "Submit Module 1");
		Task testUpdatePass2 = new Task("2", "Module 2", "Submit Module 2");
		assertEquals(true, t.add(testUpdatePass1));
		assertEquals(true, t.add(testUpdatePass2));


		assertEquals(true, t.update("1", "Module 1-1", "Submit Completed Module 1"));
		assertEquals(true, t.update("2", "Module 2-2", "submit Completed Module 2"));
}

	//test update fail
	@Test
	public void testUpdateFail() {
		TaskService t = new TaskService();
		Task testUpdateFail1 = new Task("1", "Module 1", "Submit Module 1");
		Task testUpdateFail2 = new Task("2", "Module 2", "Submit Module 2");
		assertEquals(true, t.add(testUpdateFail1));
		assertEquals(true, t.add(testUpdateFail2));

		//Update ID that does not exist
		assertEquals(false, t.update("3", "Module 1", "Submit Module 1"));
		
		assertEquals(true, t.update("2", "Module 1", "Submit Module 1"));
}

}