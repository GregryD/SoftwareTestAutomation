import java.util.ArrayList;

public class TaskService {
	//create array list to hold tasks
	private ArrayList<Task> tasks;
	
	//default constructor
	public TaskService() {
		tasks = new ArrayList<>();
	}
	
	//add task
	public boolean add(Task task) {
		//check if ID already exists
		boolean alreadyPresent = false;
		for (Task t : tasks) {
			if (t.getTaskID().equals(task.getTaskID())) {
				alreadyPresent = true;
		}}
		//if ID doesnt exist add it else return false
		if (!alreadyPresent) {
			tasks.add(task);
			return true;
		}
		else {
			return false;
		}

	}
	
	//remove task
	public boolean remove(String taskID) {
		
	//find the task to be removed and if exists delete
		for (Task t : tasks) {
			if (t.getTaskID().equals(taskID)) {
				tasks.remove(t);
				return true;
			}
		}
		return false;
	}
	//update
	public boolean update(String taskID, String name, String description) {
		for (Task t : tasks) {
			if (t.getTaskID().equals(taskID)) {
				t.setName(name);
				t.setDescription(description);

				return true;
			}
		}
		return false;
	}
	
}