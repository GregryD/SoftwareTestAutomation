
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskTest {

	@Test
	void testTask() {
		Task t = new Task("1", "Module 1", "Submit Completed Assignment");
		assertTrue(t.getTaskID().equals("1"));
		assertTrue(t.getName().equals("Module 1"));
		assertTrue(t.getDescription().equals("Submit Completed Assignment"));
	}

	@Test
	void testTaskIDToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Task("1234567891011", "George", "Submit Completed Assignment");
		}); }
	
	@Test
	void testNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Task("1", "gerogettegeorgettere1", "Submit Completed Assignment");
		}); }
	
	@Test
	void testDescriptionToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Task("1", "Module 1", "jfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfjfj" );
		}); }
	
	@Test
	void testNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Task("1", null, "Submit Module 1");
		}); }
	@Test
	void testDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Task("1", "Module 1",  null);
		}); }
}
