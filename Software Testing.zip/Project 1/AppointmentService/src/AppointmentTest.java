
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentTest {
	
	@SuppressWarnings("deprecation")
	Date passAppointmentDate = new Date(2023, 4, 4);
	@SuppressWarnings("deprecation")
	Date failAppointmentDate = new Date(2022, 8, 18);
	

	@Test
	void testAppointment() {
		Appointment a = new Appointment("1", passAppointmentDate, "Meeting with students.");
		assertTrue(a.geAppointmentID().equals("1"));
		assertTrue(a.getDate().equals(passAppointmentDate));
		assertTrue(a.getDescription().equals("Meeting with students."));
	}

	@Test
	void testAppointmentIDToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("1234567891011", passAppointmentDate, "Meeting with students.");
		}); }
	
	@Test
	void testDatePassed() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("1234567891011", failAppointmentDate, "Meeting with students.");
		}); }
	
	@Test
	void testDescriptionToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("1234567891011", passAppointmentDate, "Who indeed, after pulling off the coloured "
					+ "glasses of prejudice and thrusting out of sight his pet projects, can help seeing the folly"
					+ " of these endeavours to protect men against themselves? A sad population of imbeciles would our "
					+ "schemers fill the world with, could their plans last.");
		}); }
	
	@Test
	void testDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			Appointment a = new Appointment("1", passAppointmentDate, null);
		}); }
	
	@Test
	void testDateNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			Appointment a = new Appointment("1", null, "Meeting with students.");
		}); }
		
}
