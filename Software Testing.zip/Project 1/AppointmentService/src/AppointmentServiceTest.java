import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;


public class AppointmentServiceTest {
	
	@SuppressWarnings("deprecation")
	Date passAppointmentDate = new Date(2023, 4, 4);
	
	@SuppressWarnings("deprecation")
	Date passAppointmentDate2 = new Date(2023, 11, 5);
	
	@SuppressWarnings("deprecation")
	Date failAppointmentDate = new Date(2022, 8, 18);
	
	//testing add functionality pass
	@Test
	public void testAddPass() {
		AppointmentService a = new AppointmentService();
		Appointment testAddPass1 = new Appointment("1", passAppointmentDate, "Meeting with students.");
		Appointment testAddPass2 = new Appointment("2", passAppointmentDate2, "Meeting with teachers.");
		assertEquals(true, a.add(testAddPass1));
		assertEquals(true, a.add(testAddPass2));
	
	}

	//testing add functionality for fail
	@Test
	public void testMethodAddFail() {
		AppointmentService a = new AppointmentService();
		Appointment testAddFail1 = new Appointment("1", passAppointmentDate, "Meeting with students.");
		
		//test id already added
		assertEquals(true, a.add(testAddFail1));
		assertEquals(false, a.add(testAddFail1));

		}

	
	//test delete functionality pass
	@Test
	public void testMethodDeletePass() {
		AppointmentService a = new AppointmentService();
		Appointment testDeletePass1 = new Appointment("1", passAppointmentDate, "Meeting with students.");
		Appointment testDeletePass2 = new Appointment("2", passAppointmentDate2, "Meeting with teachers.");
		
		assertEquals(true, a.add(testDeletePass1));
		assertEquals(true, a.add(testDeletePass2));

		assertEquals(true, a.remove("1"));
		assertEquals(true, a.remove("2"));
}

	//test delete method fail
	@Test
	public void testMethodDeleteFail() {
		AppointmentService a = new AppointmentService();
		Appointment testDeleteFail1 = new Appointment("1", passAppointmentDate, "Meeting with students.");
		Appointment testDeleteFail2 = new Appointment("2", passAppointmentDate2, "Meeting with teachers.");
		assertEquals(true, a.add(testDeleteFail1));
		assertEquals(true, a.add(testDeleteFail2));
		
		//test removing contact that does not exist
		assertEquals(false, a.remove("3"));
		//test removing regular contact
		assertEquals(true, a.remove("2"));
}


}