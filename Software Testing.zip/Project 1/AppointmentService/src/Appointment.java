import java.util.Date;


public class Appointment {
	//Set variables
	private String appointmentID;
	private Date date;
	private String description;
	
	//Constructor
	public Appointment(String appointmentID, Date date, String description) {
		if (appointmentID == null || appointmentID.length() > 10) {
			throw new IllegalArgumentException("Invalid Input");
		}
		if (date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Invalid Input");
		}
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid Input");
		}
		
		this.appointmentID = appointmentID;
		this.date = date;
		this.description = description;

				
	}
	//Setters
	public void setDate(Date date) {
		this.date = date;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	//Getters
	public String geAppointmentID() {
		return appointmentID;
	}
	public Date getDate() {
		return date;
	}
	public String getDescription() {
		return description;
	}


	}