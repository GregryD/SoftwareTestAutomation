import java.util.ArrayList;

public class AppointmentService {
	//create array list to hold appointments
	private ArrayList<Appointment> appointments;
	
	//default constructor
	public AppointmentService() {
		appointments = new ArrayList<>();
	}
	
	//add appointment
	public boolean add(Appointment appointment) {
		//check if ID already exists
		boolean alreadyPresent = false;
		for (Appointment a : appointments) {
			if (a.geAppointmentID().equals(appointment.geAppointmentID())) {
				alreadyPresent = true;
		}}
		//if ID doesnt exist add it else return false
		if (!alreadyPresent) {
			appointments.add(appointment);
			return true;
		}
		else {
			return false;
		}

	}
	
	//remove contact
	public boolean remove(String appointmentID) {
		
	//find the appointment to be removed and if exists delete
		for (Appointment c : appointments) {
			if (c.geAppointmentID().equals(appointmentID)) {
				appointments.remove(c);
				return true;
			}
		}
		return false;
	}
	
	
}