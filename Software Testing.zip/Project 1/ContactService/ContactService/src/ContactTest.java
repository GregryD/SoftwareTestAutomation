
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {

	@Test
	void testContact() {
		Contact c = new Contact("1", "George", "Hoyt","3434343434", "152 Catalpa road");
		assertTrue(c.getContactID().equals("1"));
		assertTrue(c.getFirstName().equals("George"));
		assertTrue(c.getLastName().equals("Hoyt"));
		assertTrue(c.getPhone().equals("3434343434"));
		assertTrue(c.getAddress().equals("152 Catalpa road"));
	}

	@Test
	void testContactIDToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1234567891011", "George", "Hoyt","3434343434", "152 Catalpa road");
		}); }
	
	@Test
	void testPhoneToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1", "George", "Hoyt","34343434349", "152 Catalpa road");
		}); }
	
	@Test
	void testFirstNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1", "GeorgeGeorge", "Hoyt","3434343434", "152 Catalpa road");
		}); }
	
	@Test
	void testLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1", "George", null,"3434343434", "152 Catalpa road");
		}); }
	@Test
	void testAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact("1", "George", "Hoyt","3434343434", null);
		}); }
}
