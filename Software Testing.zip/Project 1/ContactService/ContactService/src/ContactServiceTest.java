import static org.junit.Assert.*;
import org.junit.Test;


public class ContactServiceTest {
	
	//testing add functionality pass
	@Test
	public void testAddPass() {
		ContactService c = new ContactService();
		Contact testAddPass1 = new Contact("1", "George", "Hoyt","3434343434", "152 Catalpa road");
		Contact testAddPass2 = new Contact("contact2", "Bimbo", "Stevenson","3434343434", "14 Cofee drive");
		assertEquals(true, c.add(testAddPass1));
		assertEquals(true, c.add(testAddPass2));
	
	}

	//testing add functionality for fail
	@Test
	public void testMethodAddFail() {
		ContactService c = new ContactService();
		Contact testAddFail1 = new Contact("001", "George", "Bush", "8978987865", "100 Applewood");

		//test id already added
		assertEquals(true, c.add(testAddFail1));
		assertEquals(false, c.add(testAddFail1));

		}

	
	//test delete functionality pass
	@Test
	public void testMethodDeletePass() {
		ContactService c = new ContactService();
		Contact testDeletePass1 = new Contact("1", "George", "Hoyt","3434343434", "152 Catalpa road");
		Contact testDeletePass2 = new Contact("contact2", "Bimbo", "Stevenson","3434343434", "14 Cofee drive");
		assertEquals(true, c.add(testDeletePass1));
		assertEquals(true, c.add(testDeletePass2));

		assertEquals(true, c.remove("1"));
		assertEquals(true, c.remove("contact2"));
}

	//test delete method fail
	@Test
	public void testMethodDeleteFail() {
		ContactService c = new ContactService();
		Contact testDeleteFail1 = new Contact("1", "George", "Hoyt","3434343434", "152 Catalpa road");
		Contact testDeleteFail2 = new Contact("contact2", "Bimbo", "Stevenson","3434343434", "14 Cofee drive");
		assertEquals(true, c.add(testDeleteFail1));
		assertEquals(true, c.add(testDeleteFail2));
		
		//test removing contact that does not exist
		assertEquals(false, c.remove("3"));
		//test removing regular contact
		assertEquals(true, c.remove("contact2"));
}

	// test update pass
	@Test
	public void testUpdatePass() {
		ContactService c = new ContactService();
		Contact testUpdatePass1 = new Contact("1", "George", "Hoyt","3434343434", "152 Catalpa road");
		Contact testUpdatePass2 = new Contact("contact2", "Bimbo", "Stevenson","3434343434", "14 Cofee drive");
		assertEquals(true, c.add(testUpdatePass1));
		assertEquals(true, c.add(testUpdatePass2));


		assertEquals(true, c.update("1", "Fred", "Hoyt","3454334343", "152 Catalpa road"));
		assertEquals(true, c.update("contact2", "Jimmy", "Apple", "4444444444", "124 play st"));
}

	//test update fail
	@Test
	public void testUpdateFail() {
		ContactService c = new ContactService();
		Contact testUpdateFail1 = new Contact("1", "George", "Hoyt","3434343434", "152 Catalpa road");
		Contact testUpdateFail2 = new Contact("contact2", "Bimbo", "Stevenson","3434343434", "14 Cofee drive");
		
		assertEquals(true, c.add(testUpdateFail1));
		assertEquals(true, c.add(testUpdateFail2));

		assertEquals(false, c.update("C004", "Sean", "Paul", "4444443232", "34 dfdf"));
		assertEquals(true, c.update("contact2", "Jimmy", "Apple", "4444444444", "124 play st"));
}

}