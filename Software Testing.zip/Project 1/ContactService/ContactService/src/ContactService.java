import java.util.ArrayList;

public class ContactService {
	//create array list to hold contacts
	private ArrayList<Contact> contacts;
	
	//default constructor
	public ContactService() {
		contacts = new ArrayList<>();
	}
	
	//add contact
	public boolean add(Contact contact) {
		//check if ID already exists
		boolean alreadyPresent = false;
		for (Contact c : contacts) {
			if (c.getContactID().equals(contact.getContactID())) {
				alreadyPresent = true;
		}}
		//if ID doesnt exist add it else return false
		if (!alreadyPresent) {
			contacts.add(contact);
			return true;
		}
		else {
			return false;
		}

	}
	
	//remove contact
	public boolean remove(String contactID) {
		
	//find the contact to be removed and if exists delete
		for (Contact c : contacts) {
			if (c.getContactID().equals(contactID)) {
				contacts.remove(c);
				return true;
			}
		}
		return false;
	}
	//update
	public boolean update(String contactID, String firstName, String lastName, String phone, String address) {
		for (Contact c : contacts) {
			if (c.getContactID().equals(contactID)) {
				c.setFirstName(firstName);
				c.setLastName(lastName);
				c.setPhone(phone);
				c.setAddress(address);
				return true;
			}
		}
		return false;
	}
	
}